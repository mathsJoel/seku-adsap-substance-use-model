import numpy as np
import matplotlib.pyplot as plt

print("="*60)
print("TEST - PYTHON IS WORKING!")
print("="*60)

# Test if numpy works
x = np.array([1, 2, 3, 4, 5])
print(f"numpy test: {x}")

# Test if matplotlib works
plt.figure(figsize=(6, 4))
plt.plot([1, 2, 3, 4], [10, 20, 25, 30], 'o-')
plt.title('Test Figure')
plt.savefig('test_figure.png')
print("test_figure.png saved!")

print("="*60)
print("TEST COMPLETE - PYTHON IS WORKING CORRECTLY!")
print("="*60)