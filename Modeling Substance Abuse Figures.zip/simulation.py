"""
SEKU ADSAP SIMULATION - FULLY CORRECTED
Dr. Joel Ngesa, South Eastern Kenya University
"""

import numpy as np
import matplotlib.pyplot as plt

print("="*60)
print("SEKU ADSAP SIMULATION - STARTING")
print("="*60)

np.random.seed(2026)

# ============================================================================
# PARAMETERS
# ============================================================================

GENDER_PROBS = [0.542, 0.458]
YEAR_PROBS = [0.269, 0.243, 0.238, 0.250]

# Residence probabilities - NORMALIZED to sum to 1
RESIDENCE_PROBS = np.array([0.254, 0.617, 0.119])
RESIDENCE_PROBS = RESIDENCE_PROBS / np.sum(RESIDENCE_PROBS)
RESIDENCE_OPTIONS = ['On-campus', 'Off-campus', 'At-home']

P_SUSCEPTIBLE = 0.544
P_USER = 0.266
P_EXPERIMENTAL = 0.190

N_STUDENTS = 200
N_SIMULATIONS = 10
N_WEEKS = 160

PARAMS = {
    'alpha': 0.12, 'beta': 1.1, 'rho': 0.35, 'gamma': 0.22,
    'delta': 0.12, 'kappa': 0.06, 'lambda_c': 0.30, 'nu': 0.09, 'omega': 0.25
}

# ============================================================================
# SIMULATION FUNCTION
# ============================================================================

def run_one_simulation(params):
    """Run one simulation, returns prevalence for years 1-4"""
    
    n_s = int(N_STUDENTS * P_SUSCEPTIBLE)
    n_u = int(N_STUDENTS * P_USER)
    n_e = N_STUDENTS - n_s - n_u
    
    states = np.zeros(N_STUDENTS, dtype=int)
    states[:n_s] = 0
    states[n_s:n_s + n_e] = 1
    states[n_s + n_e:] = 2
    
    residence = np.random.choice(RESIDENCE_OPTIONS, size=N_STUDENTS, p=RESIDENCE_PROBS)
    trauma = np.random.binomial(1, 0.30, size=N_STUDENTS)
    religiosity = np.random.binomial(1, 0.70, size=N_STUDENTS)
    stress = np.random.uniform(0, 0.3, size=N_STUDENTS)
    
    prevalence = []
    
    for week in range(N_WEEKS):
        year_idx = min(3, week // 40)
        
        stress += 0.01 * (year_idx + 1)
        stress += 0.02 * (residence == 'Off-campus')
        stress -= 0.03 * religiosity
        stress += np.random.normal(0, 0.05, size=N_STUDENTS)
        stress = np.clip(stress, 0, 1)
        
        peer = np.random.beta(2, 8, size=N_STUDENTS)
        
        # Initiation
        s_mask = (states == 0)
        p_init = params['alpha'] * (peer ** params['beta']) * (1 - params['rho'] * religiosity)
        init = (np.random.random(N_STUDENTS) < p_init) & s_mask
        states[init] = 1
        
        # Progression
        e_mask = (states == 1)
        p_prog = params['gamma'] * stress + params['delta'] * trauma
        p_prog = np.clip(p_prog, 0, 1)
        prog = (np.random.random(N_STUDENTS) < p_prog) & e_mask
        states[prog] = 2
        
        # Cessation
        u_mask = (states == 2)
        counselling = np.random.binomial(1, 0.6, size=N_STUDENTS)
        p_cess = params['kappa'] * (1 + params['lambda_c'] * counselling)
        cess = (np.random.random(N_STUDENTS) < p_cess) & u_mask
        states[cess] = 3
        
        # Relapse
        r_mask = (states == 3)
        p_relapse = params['nu'] * peer * (1 - params['omega'] * religiosity)
        relapse = (np.random.random(N_STUDENTS) < p_relapse) & r_mask
        states[relapse] = 2
        
        # Record at end of each year (weeks 40, 80, 120, 160)
        if (week + 1) % 40 == 0:
            prevalence.append(np.mean(states == 2))
    
    return np.array(prevalence)  # Returns 4 values: years 1, 2, 3, 4


# ============================================================================
# RUN SIMULATIONS
# ============================================================================

print(f"\nRunning {N_SIMULATIONS} simulations with {N_STUDENTS} students each...\n")

def run_scenario(name, mod):
    print(f"  {name}...", end=" ")
    results = []
    for i in range(N_SIMULATIONS):
        p = PARAMS.copy()
        p.update(mod)
        results.append(run_one_simulation(p))
        if (i+1) % 5 == 0:
            print(f"{i+1}", end=" ", flush=True)
    print("✓")
    return np.array(results)

# Run all scenarios
results = {
    'Baseline': run_scenario('Baseline', {}),
    'Counselling': run_scenario('Counselling', {'lambda_c': 1.4 * PARAMS['lambda_c']}),
    'Mentorship': run_scenario('Mentorship', {'alpha': 0.7 * PARAMS['alpha']}),
    'Accommodation': run_scenario('Accommodation', {'alpha': 0.7 * PARAMS['alpha']}),
    'Combined': run_scenario('Combined', {'alpha': 0.7 * PARAMS['alpha'], 
                                          'lambda_c': 1.4 * PARAMS['lambda_c']})
}

print("\n✓ All simulations complete!\n")

# ============================================================================
# GENERATE FIGURES
# ============================================================================

print("Generating figures...\n")

# FIGURE 1: Model Fit (Baseline vs NACADA)
fig, ax = plt.subplots(figsize=(8, 6))

years = [1, 2, 3, 4]
nacada = [0.216, 0.276, 0.298, 0.280]

baseline_mean = np.mean(results['Baseline'], axis=0)
baseline_low = np.percentile(results['Baseline'], 2.5, axis=0)
baseline_high = np.percentile(results['Baseline'], 97.5, axis=0)

ax.plot(years, baseline_mean, 'o-', color='blue', linewidth=2, markersize=8, label='ABM Simulation')
ax.fill_between(years, baseline_low, baseline_high, color='blue', alpha=0.2, label='95% CI')
ax.plot(years, nacada, 's-', color='red', linewidth=2, markersize=8, label='NACADA Data')

ax.set_xlabel('Year of Study')
ax.set_ylabel('Past-Month Prevalence')
ax.set_xticks(years)
ax.set_ylim(0.15, 0.35)
ax.legend(loc='lower right')
ax.set_title('Figure 1: Model Fit to NACADA Prevalence Data')

plt.tight_layout()
plt.savefig('figure1.png', dpi=150)
print("  ✓ figure1.png saved")

# FIGURE 2: Intervention Trajectories
fig, ax = plt.subplots(figsize=(10, 7))

# Create x-axis: years 1, 2, 3, 4 (not including baseline at year 0)
years_for_plot = [1, 2, 3, 4]

for name, data in results.items():
    mean_traj = np.mean(data, axis=0) * 100
    if name == 'Combined':
        ax.plot(years_for_plot, mean_traj, '-', color='red', linewidth=3, label=name)
        ci_low = np.percentile(data, 2.5, axis=0) * 100
        ci_high = np.percentile(data, 97.5, axis=0) * 100
        ax.fill_between(years_for_plot, ci_low, ci_high, color='red', alpha=0.2)
    elif name == 'Baseline':
        ax.plot(years_for_plot, mean_traj, '-', color='black', linewidth=2, label=name)
    else:
        ax.plot(years_for_plot, mean_traj, '--', linewidth=2, label=name)

ax.set_xlabel('Year of Study')
ax.set_ylabel('Overall Past-Month Prevalence (%)')
ax.set_xticks(years_for_plot)
ax.set_ylim(15, 35)
ax.grid(True, alpha=0.3)
ax.legend(loc='upper right')
ax.set_title('Figure 2: Projected Impact of Interventions Over 4 Years')

plt.tight_layout()
plt.savefig('figure2.png', dpi=150)
print("  ✓ figure2.png saved")

# FIGURE 3: Box Plot
fig, ax = plt.subplots(figsize=(10, 6))

final_prevalence = {}
for name, data in results.items():
    final_prevalence[name] = data[:, -1] * 100  # Year 4 prevalence

positions = np.arange(len(final_prevalence))
bp = ax.boxplot(final_prevalence.values(), positions=positions, widths=0.6, 
                patch_artist=True, showmeans=True,
                meanprops={'marker': 'o', 'markerfacecolor': 'white', 
                          'markeredgecolor': 'black', 'markersize': 6})

colors = ['#7570b3', '#1f78b4', '#33a02c', '#ff7f00', '#e31a23']
for patch, color in zip(bp['boxes'], colors):
    patch.set_facecolor(color)
    patch.set_alpha(0.7)

ax.set_xticks(positions)
ax.set_xticklabels(final_prevalence.keys(), rotation=45, ha='right')
ax.set_ylabel('Final Year Prevalence (%)')
ax.set_title('Figure 3: Distribution of Simulation Outcomes by Intervention')
ax.grid(True, alpha=0.3, axis='y')

plt.tight_layout()
plt.savefig('figure3.png', dpi=150)
print("  ✓ figure3.png saved")

# ============================================================================
# RESULTS SUMMARY
# ============================================================================

print("\n" + "="*60)
print("RESULTS SUMMARY")
print("="*60)

for name, data in results.items():
    final = data[:, -1] * 100
    print(f"\n{name}:")
    print(f"  Final Prevalence (Year 4): {np.mean(final):.1f}%")
    print(f"  95% CI: ({np.percentile(final, 2.5):.1f}% - {np.percentile(final, 97.5):.1f}%)")

# Calculate reductions
baseline_mean = np.mean(results['Baseline'][:, -1] * 100)
print(f"\nBaseline Mean: {baseline_mean:.1f}%")
print("-"*40)
for name in ['Counselling', 'Mentorship', 'Accommodation', 'Combined']:
    mean_val = np.mean(results[name][:, -1] * 100)
    reduction = ((baseline_mean - mean_val) / baseline_mean) * 100
    print(f"{name} Reduction: {reduction:.1f}%")

print("\n" + "="*60)
print("SIMULATION COMPLETE!")
print("="*60)
print("\nGenerated files in your folder:")
print("  📊 figure1.png")
print("  📊 figure2.png")
print("  📊 figure3.png")
print("\nOpen these images to view your results.")